# Shardfall Medieval Equipment Art v1
Original generated static artwork, separated into transparent RGBA PNGs and RGB channel-weight masks. Open preview.html offline to test palette changes. The palette values are a snapshot of layered-armor-v1; the live game must use EQ.matColor and existing item definitions.

- `master.png`: source sheet with cleaned transparent background.
- `pieces/`: individual art; `__image_left` and `__image_right` are separated image-side arms/hands, not anatomical or rig direction.
- `masks/`: automatic per-pixel mask proposals; red primary, green secondary, blue fixed; alpha matches art. Review especially metal fittings, leather straps, shield heraldry and cloth trim.
- `manifest.json`: inventory and asset paths. `*_concept` IDs are proposals, not new gameplay items.
- `preview.html`: offline static palette test, not a game patch.

Do not paste these pieces onto the current rig. The torso art includes shoulder/sleeve portions, and poses, scale, and hand positions do not match the moving body. Need a fitted male/female paperdoll and a pose-aware painted world overlay pass, aligned to classic-humans-v2 (112x100, anchor 56,86, 8 directions, 29 animations). Use independent item IDs/material per slot, not a whole-body tint. Preserve existing rules, save format and NPC behavior. All missing gear IDs and geometry remain explicitly missing.
