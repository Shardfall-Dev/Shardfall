Shardfall Classic Humans v1
Original generated art. 16 idle frames, 8 directions per body type. No motion frames.
Use classic_humans_idle_v1.png with its JSON. The compact atlas is optional.
Claude implementation handoff: https://github.com/Shardfall-Dev/Shardfall/blob/main/docs/handoffs/classic-human-sprites-v1.md
Handoff commit: 654e1f0a88b55fd6dc71131cefe6e4f64cd518a7
